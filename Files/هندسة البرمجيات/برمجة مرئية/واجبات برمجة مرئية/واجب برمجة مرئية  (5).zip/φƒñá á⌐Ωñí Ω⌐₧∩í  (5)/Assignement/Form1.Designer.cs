﻿namespace Assignement
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnCreateControls = new Button();
            comboBox1 = new ComboBox();
            txtNumberOfControls = new TextBox();
            pnlDynamicControls = new Panel();
            label1 = new Label();
            label2 = new Label();
            SuspendLayout();
            // 
            // btnCreateControls
            // 
            btnCreateControls.Location = new Point(186, 258);
            btnCreateControls.Name = "btnCreateControls";
            btnCreateControls.Size = new Size(163, 68);
            btnCreateControls.TabIndex = 0;
            btnCreateControls.Text = "Create Controls";
            btnCreateControls.UseVisualStyleBackColor = true;
            btnCreateControls.Click += btnCreateControls_Click;
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "Button", "TextBox", "Label" });
            comboBox1.Location = new Point(143, 102);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(236, 28);
            comboBox1.TabIndex = 1;
            // 
            // txtNumberOfControls
            // 
            txtNumberOfControls.Location = new Point(143, 168);
            txtNumberOfControls.Name = "txtNumberOfControls";
            txtNumberOfControls.Size = new Size(236, 27);
            txtNumberOfControls.TabIndex = 2;
            // 
            // pnlDynamicControls
            // 
            pnlDynamicControls.BackColor = Color.FromArgb(255, 128, 0);
            pnlDynamicControls.Location = new Point(423, 102);
            pnlDynamicControls.Name = "pnlDynamicControls";
            pnlDynamicControls.Size = new Size(450, 394);
            pnlDynamicControls.TabIndex = 3;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(44, 105);
            label1.Name = "label1";
            label1.Size = new Size(93, 20);
            label1.TabIndex = 4;
            label1.Text = "Control Type";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(-1, 171);
            label2.Name = "label2";
            label2.Size = new Size(138, 20);
            label2.TabIndex = 5;
            label2.Text = "Number of controls";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(255, 128, 255);
            ClientSize = new Size(954, 677);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(pnlDynamicControls);
            Controls.Add(txtNumberOfControls);
            Controls.Add(comboBox1);
            Controls.Add(btnCreateControls);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnCreateControls;
        private ComboBox comboBox1;
        private TextBox txtNumberOfControls;
        private Panel pnlDynamicControls;
        private Label label1;
        private Label label2;
    }
}