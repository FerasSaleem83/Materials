﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculator
{
    public enum CalculatorState
    {
        firstNumberInput = 1,
        secondNumberInput = 2
    }

    public enum OperationState
    {
        add = 0,
        sub = 1,
        mul = 2,
        div = 3
    }
}
