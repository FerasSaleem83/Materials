﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Sockets;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Data.SqlTypes;
using static System.Net.WebRequestMethods;

namespace Cleint_Server
{
    public partial class Form1 : Form
    {
        private TcpClient Client;
        private StreamReader STR;
        private StreamWriter STW;
        private string reseve;
        private string TextToSend;
        private TcpListener lisener;

        private long d2 = 0;
        private long n2;

        private long e1 = 0;
        private long n1;

        private string Ciphertext;
        private IPAddress address;

        public Form1()
        {
            InitializeComponent();
            IPAddress localIpAddress = null;
            IPAddress[] localIPs = Dns.GetHostAddresses(Dns.GetHostName());

            foreach (IPAddress address in localIPs)
            {
                if (address.AddressFamily == AddressFamily.InterNetwork)
                {
                    localIpAddress = address;
                    break; // Found a valid IPv4 address, so exit the loop
                }
            }

            if (localIpAddress != null)
            {
                foreach (IPAddress address in localIPs)
                {
                    if (address.AddressFamily == AddressFamily.InterNetwork)
                    {
                        STextBoxIP.Text = address.ToString();
                        STextBoxPO.Text = "80";
                    }
                }
            }
            else
            {
                // Handle the case when a valid local IP address is not found
                MessageBox.Show("No valid local IP address found.", "Error");
            }
            
            

        }

        private void btnCopy_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtPublicKey_n.Text))
            {
                Clipboard.SetText(txtPublicKey_n.Text);
                MessageBox.Show("Text successfully copied", "Alert");
            }
            else
            {
                MessageBox.Show("No key is selected to copy", "Alert");
            }
        }

        private void btnEncrypt_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtPublicKey_e.Text) || string.IsNullOrEmpty(txtPublicKey_n.Text) || string.IsNullOrEmpty(EnterPT.Text))
            {
                MessageBox.Show("Please, Enter public key e, n, and plaintext", "Alert");
            }
            else
            {
                e1 = long.Parse(txtPublicKey_e.Text);
                n1 = long.Parse(txtPublicKey_n.Text);

                string plaintext = EnterPT.Text;
                Ciphertext = string.Join(",", plaintext.Select(t => ModPow((int)t, e1, n1).ToString()));

                txtCipherText_int.Text = Ciphertext; // Ascii to Decimal Encryption

                string input = Ciphertext;
                string CiphertextHex = string.Join("t", input.Split(',').Select(x => Convert.ToInt32(x).ToString("x")));
                txtCipherText_hex.Text = CiphertextHex; // Decimal To hex

                EnterCT.Text = CiphertextHex;
            }
        }

        public string Enc(string XL)
        {
            e1 = long.Parse(txtPublicKey_e.Text);
            n1 = long.Parse(txtPublicKey_n.Text);

            string plaintext = EnterPT.Text;
            Ciphertext = string.Join(",", plaintext.Select(t => ModPow((int)t, e1, n1).ToString()));

            txtCipherText_int.Text = Ciphertext;

            string input = Ciphertext;
            string CiphertextHex = string.Join("t", input.Split(',').Select(x => Convert.ToInt32(x).ToString("x")));
            CHATTextBox.Text += CiphertextHex;

            string CiphertextHexc = string.Join("t", input.Split(',').Select(x => Convert.ToInt32(x).ToString("x")));
            EnterCT.Text = CiphertextHexc;

            return Ciphertext;
        }





        private void btnClear_Click(object sender, EventArgs e)
        {
            e1 = 0;
            n1 = 0;
            EnterPT.Text = "";
            txtCipherText_int.Text = "";
            txtCipherText_hex.Text = "";
        }
        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Decrypt_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(PrKey_d.Text) && !string.IsNullOrEmpty(txtPublicKey_n.Text) && !string.IsNullOrEmpty(EnterCT.Text))
            {
                d2 = long.Parse(PrKey_d.Text);
                n2 = long.Parse(txtPublicKey_n.Text);


                string CiphertextDec = EnterCT.Text;
                string[] CiphertextDecSplit = CiphertextDec.Split('t');
                string[] CiphertextDecInt = new string[CiphertextDecSplit.Length];

                for (int i = 0; i < CiphertextDecSplit.Length; i++)
                {
                    CiphertextDecInt[i] = ((char)((int)Math.Pow(long.Parse(CiphertextDecSplit[i], System.Globalization.NumberStyles.HexNumber), d2) % n2)).ToString();
                }

                PT_int.Text = string.Join(",", CiphertextDecInt);

                string CiphertextToAscii = PT_int.Text;
                string[] Parts = CiphertextToAscii.Split(',');
                StringBuilder decryptedText = new StringBuilder();

                foreach (string part in Parts)
                {
                    long plaintext1 = ModPow(long.Parse(part), d2, n2);
                    char plaintextAscii = (char)(int)plaintext1;
                    decryptedText.Append(plaintextAscii);
                }

                ShowPT.Text = decryptedText.ToString();
            }
            else
            {
                MessageBox.Show("Please, Enter private key d, n, and ciphertext (in hex)", "Alert");
            }
        }

        private void Copyd_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(PrKey_d.Text))
            {
                Clipboard.SetText(PrKey_d.Text);
                MessageBox.Show("Text successfully copied", "Alert");
            }
            else
            {
                MessageBox.Show("No key is selected to copy", "Alert");
            }
        }

        private void Dclear_Click(object sender, EventArgs e)
        {
            EnterCT.Text = "";
            PT_int.Text = "";
            ShowPT.Text = "";
        }

        private void STARTButton_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(CHATTextBox.Text))
            {
                CHATTextBox.AppendText("Starting to listen on port 80 >>" + Environment.NewLine);
            }
            else
            {
                CHATTextBox.AppendText("");
                STARTButton.Text = "Connected";
                STARTButton.Enabled = false;
                CTextBoxIP.Enabled = false;
                CTextBoxPO.Enabled = false;
            }

            try
            {
                lisener = new TcpListener(address, int.Parse(STextBoxPO.Text));
                lisener.Start();

                CHATTextBox.Text += "Client has connected" + Environment.NewLine;

                Client = lisener.AcceptTcpClient();
                STR = new StreamReader(Client.GetStream());
                STW = new StreamWriter(Client.GetStream());
                STW.AutoFlush = true;
                BackgroundWorker1.RunWorkerAsync();
                BackgroundWorker2.WorkerSupportsCancellation = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void CONECTButton_Click(object sender, EventArgs e)
        {
            try
            {
                IPEndPoint IPEnd = new IPEndPoint(IPAddress.Parse(CTextBoxIP.Text), int.Parse(CTextBoxPO.Text));
                Client = new TcpClient();

                try
                {
                    Client.Connect(IPEnd);

                    if (Client.Connected)
                    {
                        CHATTextBox.AppendText("You are now connected to the server " + Environment.NewLine);
                        STW = new StreamWriter(Client.GetStream());
                        STR = new StreamReader(Client.GetStream());
                        STW.AutoFlush = true;
                        BackgroundWorker1.RunWorkerAsync();
                        BackgroundWorker2.WorkerSupportsCancellation = true;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            CONECTButton.Text = "connected";
            CONECTButton.Enabled = false;
            CTextBoxIP.Enabled = false;
            CTextBoxPO.Enabled = false;
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            if (CHATTextBox.Text == "")
            {
                MessageBox.Show("The screen is empty", "Alert");
            }
            else
            {
                CHATTextBox.Text = "";
            }
        }

        private void Dexit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void SENDButton_Click(object sender, EventArgs e)
        {
            if (SENDTextBox.Text != "")
            {
                TextToSend = SENDTextBox.Text;
                BackgroundWorker2.RunWorkerAsync();
            }

            SENDTextBox.Text = "";
        }
        private long ModPow(long baseValue, long exponent, long modulus)
        {
            long result = 1;
            baseValue = baseValue % modulus;

            while (exponent > 0)
            {
                if (exponent % 2 == 1)
                    result = (result * baseValue) % modulus;

                exponent = exponent >> 1;
                baseValue = (baseValue * baseValue) % modulus;
            }

            return result;
        }

        private void BackgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
            while (Client.Connected)
            {
                try
                {
                    reseve = STR.ReadLine();
                    CHATTextBox.Invoke(new MethodInvoker(delegate
                    {
                        CHATTextBox.AppendText(Enc(reseve) + " < You > " + Environment.NewLine);
                    }));
                    reseve = "";
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void BackgroundWorker2_DoWork(object sender, DoWorkEventArgs e)
        {
            if (Client.Connected)
            {
                STW.WriteLine(TextToSend);
                CHATTextBox.Invoke(new MethodInvoker(delegate
                {
                    CHATTextBox.AppendText(" < Me > " + TextToSend + Environment.NewLine);
                }));
            }
            else
            {
                MessageBox.Show("Sending Failed !");
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            txtCipherText_int.Enabled = false;
            txtCipherText_hex.Enabled = false;
            PT_int.Enabled = false;
            ShowPT.Enabled = false;
            CHATTextBox.Enabled = false;
            STextBoxIP.Enabled = false;
            STextBoxPO.Enabled = false;
        }

       
    }
}
