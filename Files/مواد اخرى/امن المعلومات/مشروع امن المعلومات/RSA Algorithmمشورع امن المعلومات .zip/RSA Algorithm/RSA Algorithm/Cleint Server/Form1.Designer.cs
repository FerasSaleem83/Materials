﻿namespace Cleint_Server
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.btnCopy = new System.Windows.Forms.Button();
            this.txtPublicKey_n = new System.Windows.Forms.TextBox();
            this.txtPublicKey_e = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtCipherText_int = new System.Windows.Forms.TextBox();
            this.txtCipherText_hex = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.txtEnterPlain = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.btnEncrypt = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.EnterPT = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.Button1 = new System.Windows.Forms.Button();
            this.Dexit = new System.Windows.Forms.Button();
            this.SENDTextBox = new System.Windows.Forms.TextBox();
            this.CHATTextBox = new System.Windows.Forms.TextBox();
            this.SENDButton = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.CTextBoxIP = new System.Windows.Forms.TextBox();
            this.Label9 = new System.Windows.Forms.Label();
            this.CTextBoxPO = new System.Windows.Forms.TextBox();
            this.CONECTButton = new System.Windows.Forms.Button();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.Label18 = new System.Windows.Forms.Label();
            this.STextBoxIP = new System.Windows.Forms.TextBox();
            this.Label19 = new System.Windows.Forms.Label();
            this.STextBoxPO = new System.Windows.Forms.TextBox();
            this.STARTButton = new System.Windows.Forms.Button();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.Label15 = new System.Windows.Forms.Label();
            this.Label16 = new System.Windows.Forms.Label();
            this.ShowPT = new System.Windows.Forms.TextBox();
            this.PT_int = new System.Windows.Forms.TextBox();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.Label14 = new System.Windows.Forms.Label();
            this.EnterCT = new System.Windows.Forms.TextBox();
            this.Decrypt = new System.Windows.Forms.Button();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.Label17 = new System.Windows.Forms.Label();
            this.PrKey_d = new System.Windows.Forms.TextBox();
            this.Copyd = new System.Windows.Forms.Button();
            this.Dclear = new System.Windows.Forms.Button();
            this.BackgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.BackgroundWorker2 = new System.ComponentModel.BackgroundWorker();
            this.tabControl1.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(800, 516);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.Black;
            this.tabPage3.Controls.Add(this.groupBox5);
            this.tabPage3.Controls.Add(this.btnClear);
            this.tabPage3.Controls.Add(this.btnExit);
            this.tabPage3.Controls.Add(this.groupBox3);
            this.tabPage3.Controls.Add(this.groupBox4);
            this.tabPage3.Controls.Add(this.groupBox2);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(792, 487);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Ecrypt(RSA)";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.btnCopy);
            this.groupBox5.Controls.Add(this.txtPublicKey_n);
            this.groupBox5.Controls.Add(this.txtPublicKey_e);
            this.groupBox5.Controls.Add(this.label7);
            this.groupBox5.Controls.Add(this.label8);
            this.groupBox5.Font = new System.Drawing.Font("Segoe Print", 10.2F);
            this.groupBox5.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.groupBox5.Location = new System.Drawing.Point(32, 10);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(188, 205);
            this.groupBox5.TabIndex = 58;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "public key and n";
            // 
            // btnCopy
            // 
            this.btnCopy.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnCopy.Font = new System.Drawing.Font("Segoe Print", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCopy.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnCopy.Location = new System.Drawing.Point(43, 144);
            this.btnCopy.Name = "btnCopy";
            this.btnCopy.Size = new System.Drawing.Size(101, 48);
            this.btnCopy.TabIndex = 5;
            this.btnCopy.Text = "Copy";
            this.btnCopy.UseVisualStyleBackColor = false;
            this.btnCopy.Click += new System.EventHandler(this.btnCopy_Click);
            // 
            // txtPublicKey_n
            // 
            this.txtPublicKey_n.Location = new System.Drawing.Point(76, 91);
            this.txtPublicKey_n.Name = "txtPublicKey_n";
            this.txtPublicKey_n.Size = new System.Drawing.Size(79, 38);
            this.txtPublicKey_n.TabIndex = 8;
            // 
            // txtPublicKey_e
            // 
            this.txtPublicKey_e.Location = new System.Drawing.Point(76, 42);
            this.txtPublicKey_e.Name = "txtPublicKey_e";
            this.txtPublicKey_e.Size = new System.Drawing.Size(79, 38);
            this.txtPublicKey_e.TabIndex = 7;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label7.Location = new System.Drawing.Point(21, 99);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(49, 30);
            this.label7.TabIndex = 6;
            this.label7.Text = "n = ";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label8.Location = new System.Drawing.Point(21, 50);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(40, 30);
            this.label8.TabIndex = 5;
            this.label8.Text = "e =";
            // 
            // btnClear
            // 
            this.btnClear.BackColor = System.Drawing.Color.Black;
            this.btnClear.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClear.Font = new System.Drawing.Font("Segoe Print", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.ForeColor = System.Drawing.Color.White;
            this.btnClear.Location = new System.Drawing.Point(658, 436);
            this.btnClear.Margin = new System.Windows.Forms.Padding(4);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(102, 41);
            this.btnClear.TabIndex = 60;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.RosyBrown;
            this.btnExit.Cursor = System.Windows.Forms.Cursors.No;
            this.btnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.ForeColor = System.Drawing.Color.Black;
            this.btnExit.Location = new System.Drawing.Point(32, 441);
            this.btnExit.Margin = new System.Windows.Forms.Padding(4);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(94, 36);
            this.btnExit.TabIndex = 59;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.txtCipherText_int);
            this.groupBox3.Controls.Add(this.txtCipherText_hex);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Font = new System.Drawing.Font("Segoe Print", 10.2F);
            this.groupBox3.ForeColor = System.Drawing.Color.DarkOrchid;
            this.groupBox3.Location = new System.Drawing.Point(32, 221);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(728, 205);
            this.groupBox3.TabIndex = 58;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Encryption";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.DarkOrchid;
            this.label5.Location = new System.Drawing.Point(25, 154);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(170, 30);
            this.label5.TabIndex = 40;
            this.label5.Text = "Cipher text in hex";
            // 
            // txtCipherText_int
            // 
            this.txtCipherText_int.BackColor = System.Drawing.Color.White;
            this.txtCipherText_int.Cursor = System.Windows.Forms.Cursors.No;
            this.txtCipherText_int.Font = new System.Drawing.Font("Consolas", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCipherText_int.ForeColor = System.Drawing.Color.Black;
            this.txtCipherText_int.Location = new System.Drawing.Point(205, 40);
            this.txtCipherText_int.Margin = new System.Windows.Forms.Padding(4);
            this.txtCipherText_int.Multiline = true;
            this.txtCipherText_int.Name = "txtCipherText_int";
            this.txtCipherText_int.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal;
            this.txtCipherText_int.Size = new System.Drawing.Size(473, 61);
            this.txtCipherText_int.TabIndex = 38;
            // 
            // txtCipherText_hex
            // 
            this.txtCipherText_hex.BackColor = System.Drawing.Color.White;
            this.txtCipherText_hex.Cursor = System.Windows.Forms.Cursors.No;
            this.txtCipherText_hex.Font = new System.Drawing.Font("Consolas", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCipherText_hex.ForeColor = System.Drawing.Color.Black;
            this.txtCipherText_hex.Location = new System.Drawing.Point(205, 123);
            this.txtCipherText_hex.Margin = new System.Windows.Forms.Padding(4);
            this.txtCipherText_hex.Multiline = true;
            this.txtCipherText_hex.Name = "txtCipherText_hex";
            this.txtCipherText_hex.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal;
            this.txtCipherText_hex.Size = new System.Drawing.Size(473, 61);
            this.txtCipherText_hex.TabIndex = 39;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.DarkOrchid;
            this.label3.Location = new System.Drawing.Point(25, 71);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(173, 30);
            this.label3.TabIndex = 1;
            this.label3.Text = " Cipher text as int";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.txtEnterPlain);
            this.groupBox4.Controls.Add(this.label6);
            this.groupBox4.Controls.Add(this.btnEncrypt);
            this.groupBox4.Font = new System.Drawing.Font("Segoe Print", 10.2F);
            this.groupBox4.ForeColor = System.Drawing.Color.MediumSpringGreen;
            this.groupBox4.Location = new System.Drawing.Point(236, 10);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(524, 205);
            this.groupBox4.TabIndex = 57;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Encryption";
            // 
            // txtEnterPlain
            // 
            this.txtEnterPlain.BackColor = System.Drawing.Color.White;
            this.txtEnterPlain.Font = new System.Drawing.Font("Microsoft Tai Le", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEnterPlain.Location = new System.Drawing.Point(189, 38);
            this.txtEnterPlain.Margin = new System.Windows.Forms.Padding(4);
            this.txtEnterPlain.Multiline = true;
            this.txtEnterPlain.Name = "txtEnterPlain";
            this.txtEnterPlain.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtEnterPlain.Size = new System.Drawing.Size(328, 87);
            this.txtEnterPlain.TabIndex = 36;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.MediumSpringGreen;
            this.label6.Location = new System.Drawing.Point(6, 73);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(157, 30);
            this.label6.TabIndex = 1;
            this.label6.Text = "Enter plain text:";
            // 
            // btnEncrypt
            // 
            this.btnEncrypt.BackColor = System.Drawing.Color.MediumSpringGreen;
            this.btnEncrypt.Font = new System.Drawing.Font("Segoe Print", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEncrypt.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnEncrypt.Location = new System.Drawing.Point(287, 144);
            this.btnEncrypt.Name = "btnEncrypt";
            this.btnEncrypt.Size = new System.Drawing.Size(110, 48);
            this.btnEncrypt.TabIndex = 0;
            this.btnEncrypt.Text = "Encrypt";
            this.btnEncrypt.UseVisualStyleBackColor = false;
            this.btnEncrypt.Click += new System.EventHandler(this.btnEncrypt_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.EnterPT);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.button2);
            this.groupBox2.Font = new System.Drawing.Font("Segoe Print", 10.2F);
            this.groupBox2.ForeColor = System.Drawing.Color.MediumSpringGreen;
            this.groupBox2.Location = new System.Drawing.Point(236, 10);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(524, 205);
            this.groupBox2.TabIndex = 57;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Encryption";
            // 
            // EnterPT
            // 
            this.EnterPT.BackColor = System.Drawing.Color.White;
            this.EnterPT.Font = new System.Drawing.Font("Microsoft Tai Le", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EnterPT.Location = new System.Drawing.Point(189, 38);
            this.EnterPT.Margin = new System.Windows.Forms.Padding(4);
            this.EnterPT.Multiline = true;
            this.EnterPT.Name = "EnterPT";
            this.EnterPT.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.EnterPT.Size = new System.Drawing.Size(328, 87);
            this.EnterPT.TabIndex = 36;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.MediumSpringGreen;
            this.label4.Location = new System.Drawing.Point(6, 73);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(157, 30);
            this.label4.TabIndex = 1;
            this.label4.Text = "Enter plain text:";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.MediumSpringGreen;
            this.button2.Font = new System.Drawing.Font("Segoe Print", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button2.Location = new System.Drawing.Point(287, 144);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(110, 48);
            this.button2.TabIndex = 0;
            this.button2.Text = "Encrypt";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.Black;
            this.tabPage2.Controls.Add(this.Button1);
            this.tabPage2.Controls.Add(this.Dexit);
            this.tabPage2.Controls.Add(this.SENDTextBox);
            this.tabPage2.Controls.Add(this.CHATTextBox);
            this.tabPage2.Controls.Add(this.SENDButton);
            this.tabPage2.Controls.Add(this.groupBox1);
            this.tabPage2.Controls.Add(this.groupBox6);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(792, 487);
            this.tabPage2.TabIndex = 3;
            this.tabPage2.Text = "tabPage2";
            // 
            // Button1
            // 
            this.Button1.BackColor = System.Drawing.Color.Black;
            this.Button1.Font = new System.Drawing.Font("Segoe Print", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(160)))), ((int)(((byte)(157)))));
            this.Button1.Location = new System.Drawing.Point(453, 308);
            this.Button1.Name = "Button1";
            this.Button1.Size = new System.Drawing.Size(213, 77);
            this.Button1.TabIndex = 40;
            this.Button1.Text = "Clear";
            this.Button1.UseVisualStyleBackColor = false;
            this.Button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // Dexit
            // 
            this.Dexit.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.Dexit.Cursor = System.Windows.Forms.Cursors.No;
            this.Dexit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Dexit.ForeColor = System.Drawing.Color.Black;
            this.Dexit.Location = new System.Drawing.Point(453, 392);
            this.Dexit.Margin = new System.Windows.Forms.Padding(4);
            this.Dexit.Name = "Dexit";
            this.Dexit.Size = new System.Drawing.Size(213, 54);
            this.Dexit.TabIndex = 39;
            this.Dexit.Text = "Exit";
            this.Dexit.UseVisualStyleBackColor = false;
            this.Dexit.Click += new System.EventHandler(this.Dexit_Click);
            // 
            // SENDTextBox
            // 
            this.SENDTextBox.BackColor = System.Drawing.Color.White;
            this.SENDTextBox.Font = new System.Drawing.Font("Microsoft Tai Le", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SENDTextBox.Location = new System.Drawing.Point(5, 391);
            this.SENDTextBox.Multiline = true;
            this.SENDTextBox.Name = "SENDTextBox";
            this.SENDTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal;
            this.SENDTextBox.Size = new System.Drawing.Size(354, 55);
            this.SENDTextBox.TabIndex = 37;
            // 
            // CHATTextBox
            // 
            this.CHATTextBox.BackColor = System.Drawing.Color.White;
            this.CHATTextBox.Cursor = System.Windows.Forms.Cursors.No;
            this.CHATTextBox.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CHATTextBox.ForeColor = System.Drawing.Color.Black;
            this.CHATTextBox.Location = new System.Drawing.Point(6, 16);
            this.CHATTextBox.Multiline = true;
            this.CHATTextBox.Name = "CHATTextBox";
            this.CHATTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.CHATTextBox.Size = new System.Drawing.Size(442, 372);
            this.CHATTextBox.TabIndex = 36;
            // 
            // SENDButton
            // 
            this.SENDButton.BackColor = System.Drawing.Color.RosyBrown;
            this.SENDButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SENDButton.Font = new System.Drawing.Font("Segoe Print", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SENDButton.ForeColor = System.Drawing.Color.Black;
            this.SENDButton.Location = new System.Drawing.Point(364, 391);
            this.SENDButton.Name = "SENDButton";
            this.SENDButton.Size = new System.Drawing.Size(83, 55);
            this.SENDButton.TabIndex = 38;
            this.SENDButton.Text = "SEND";
            this.SENDButton.UseVisualStyleBackColor = false;
            this.SENDButton.Click += new System.EventHandler(this.SENDButton_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.CTextBoxIP);
            this.groupBox1.Controls.Add(this.Label9);
            this.groupBox1.Controls.Add(this.CTextBoxPO);
            this.groupBox1.Controls.Add(this.CONECTButton);
            this.groupBox1.ForeColor = System.Drawing.Color.RosyBrown;
            this.groupBox1.Location = new System.Drawing.Point(453, 161);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(213, 141);
            this.groupBox1.TabIndex = 35;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Cleint";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.RosyBrown;
            this.label1.Location = new System.Drawing.Point(5, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(20, 17);
            this.label1.TabIndex = 5;
            this.label1.Text = "IP";
            // 
            // CTextBoxIP
            // 
            this.CTextBoxIP.Location = new System.Drawing.Point(27, 27);
            this.CTextBoxIP.Name = "CTextBoxIP";
            this.CTextBoxIP.Size = new System.Drawing.Size(175, 24);
            this.CTextBoxIP.TabIndex = 7;
            // 
            // Label9
            // 
            this.Label9.AutoSize = true;
            this.Label9.Location = new System.Drawing.Point(5, 62);
            this.Label9.Name = "Label9";
            this.Label9.Size = new System.Drawing.Size(34, 17);
            this.Label9.TabIndex = 8;
            this.Label9.Text = "Port";
            // 
            // CTextBoxPO
            // 
            this.CTextBoxPO.Location = new System.Drawing.Point(44, 63);
            this.CTextBoxPO.Name = "CTextBoxPO";
            this.CTextBoxPO.Size = new System.Drawing.Size(32, 24);
            this.CTextBoxPO.TabIndex = 9;
            // 
            // CONECTButton
            // 
            this.CONECTButton.BackColor = System.Drawing.Color.RosyBrown;
            this.CONECTButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CONECTButton.ForeColor = System.Drawing.Color.Black;
            this.CONECTButton.Location = new System.Drawing.Point(44, 101);
            this.CONECTButton.Name = "CONECTButton";
            this.CONECTButton.Size = new System.Drawing.Size(158, 34);
            this.CONECTButton.TabIndex = 6;
            this.CONECTButton.Text = "CONNECT";
            this.CONECTButton.UseVisualStyleBackColor = false;
            this.CONECTButton.Click += new System.EventHandler(this.CONECTButton_Click);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.Label18);
            this.groupBox6.Controls.Add(this.STextBoxIP);
            this.groupBox6.Controls.Add(this.Label19);
            this.groupBox6.Controls.Add(this.STextBoxPO);
            this.groupBox6.Controls.Add(this.STARTButton);
            this.groupBox6.ForeColor = System.Drawing.Color.RosyBrown;
            this.groupBox6.Location = new System.Drawing.Point(453, 13);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(213, 142);
            this.groupBox6.TabIndex = 34;
            this.groupBox6.TabStop = false;
            this.groupBox6.Tag = "";
            this.groupBox6.Text = "Server";
            // 
            // Label18
            // 
            this.Label18.AutoSize = true;
            this.Label18.Location = new System.Drawing.Point(6, 37);
            this.Label18.Name = "Label18";
            this.Label18.Size = new System.Drawing.Size(20, 17);
            this.Label18.TabIndex = 0;
            this.Label18.Text = "IP";
            // 
            // STextBoxIP
            // 
            this.STextBoxIP.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.STextBoxIP.ForeColor = System.Drawing.Color.Black;
            this.STextBoxIP.Location = new System.Drawing.Point(32, 27);
            this.STextBoxIP.Name = "STextBoxIP";
            this.STextBoxIP.Size = new System.Drawing.Size(170, 27);
            this.STextBoxIP.TabIndex = 2;
            // 
            // Label19
            // 
            this.Label19.AutoSize = true;
            this.Label19.Location = new System.Drawing.Point(6, 72);
            this.Label19.Name = "Label19";
            this.Label19.Size = new System.Drawing.Size(34, 17);
            this.Label19.TabIndex = 3;
            this.Label19.Text = "Port";
            // 
            // STextBoxPO
            // 
            this.STextBoxPO.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.STextBoxPO.ForeColor = System.Drawing.Color.Black;
            this.STextBoxPO.Location = new System.Drawing.Point(44, 62);
            this.STextBoxPO.Name = "STextBoxPO";
            this.STextBoxPO.Size = new System.Drawing.Size(32, 27);
            this.STextBoxPO.TabIndex = 4;
            // 
            // STARTButton
            // 
            this.STARTButton.BackColor = System.Drawing.Color.RosyBrown;
            this.STARTButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.STARTButton.ForeColor = System.Drawing.Color.Black;
            this.STARTButton.Location = new System.Drawing.Point(44, 97);
            this.STARTButton.Name = "STARTButton";
            this.STARTButton.Size = new System.Drawing.Size(158, 39);
            this.STARTButton.TabIndex = 1;
            this.STARTButton.Text = "START";
            this.STARTButton.UseVisualStyleBackColor = false;
            this.STARTButton.Click += new System.EventHandler(this.STARTButton_Click);
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.Black;
            this.tabPage1.Controls.Add(this.groupBox7);
            this.tabPage1.Controls.Add(this.groupBox8);
            this.tabPage1.Controls.Add(this.groupBox9);
            this.tabPage1.Controls.Add(this.Dclear);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(792, 487);
            this.tabPage1.TabIndex = 4;
            this.tabPage1.Text = "tabPage1";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.Label15);
            this.groupBox7.Controls.Add(this.Label16);
            this.groupBox7.Controls.Add(this.ShowPT);
            this.groupBox7.Controls.Add(this.PT_int);
            this.groupBox7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox7.ForeColor = System.Drawing.Color.RosyBrown;
            this.groupBox7.Location = new System.Drawing.Point(8, 203);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(644, 178);
            this.groupBox7.TabIndex = 41;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Plain Texts";
            // 
            // Label15
            // 
            this.Label15.AutoSize = true;
            this.Label15.Location = new System.Drawing.Point(2, 61);
            this.Label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label15.Name = "Label15";
            this.Label15.Size = new System.Drawing.Size(118, 20);
            this.Label15.TabIndex = 33;
            this.Label15.Text = "Cipher text int:";
            // 
            // Label16
            // 
            this.Label16.AutoSize = true;
            this.Label16.Location = new System.Drawing.Point(2, 119);
            this.Label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label16.Name = "Label16";
            this.Label16.Size = new System.Drawing.Size(81, 20);
            this.Label16.TabIndex = 32;
            this.Label16.Text = "plain text:";
            // 
            // ShowPT
            // 
            this.ShowPT.BackColor = System.Drawing.Color.White;
            this.ShowPT.Cursor = System.Windows.Forms.Cursors.No;
            this.ShowPT.Font = new System.Drawing.Font("Consolas", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ShowPT.Location = new System.Drawing.Point(121, 110);
            this.ShowPT.Margin = new System.Windows.Forms.Padding(4);
            this.ShowPT.Multiline = true;
            this.ShowPT.Name = "ShowPT";
            this.ShowPT.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal;
            this.ShowPT.Size = new System.Drawing.Size(478, 61);
            this.ShowPT.TabIndex = 28;
            // 
            // PT_int
            // 
            this.PT_int.BackColor = System.Drawing.Color.White;
            this.PT_int.Cursor = System.Windows.Forms.Cursors.No;
            this.PT_int.Font = new System.Drawing.Font("Consolas", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PT_int.Location = new System.Drawing.Point(121, 41);
            this.PT_int.Margin = new System.Windows.Forms.Padding(4);
            this.PT_int.Multiline = true;
            this.PT_int.Name = "PT_int";
            this.PT_int.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal;
            this.PT_int.Size = new System.Drawing.Size(478, 61);
            this.PT_int.TabIndex = 29;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.Label14);
            this.groupBox8.Controls.Add(this.EnterCT);
            this.groupBox8.Controls.Add(this.Decrypt);
            this.groupBox8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(140)))), ((int)(((byte)(81)))));
            this.groupBox8.Location = new System.Drawing.Point(166, 6);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(486, 191);
            this.groupBox8.TabIndex = 40;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Decryption";
            // 
            // Label14
            // 
            this.Label14.AutoSize = true;
            this.Label14.Location = new System.Drawing.Point(6, 65);
            this.Label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label14.Name = "Label14";
            this.Label14.Size = new System.Drawing.Size(134, 20);
            this.Label14.TabIndex = 25;
            this.Label14.Text = "Ciphertext in hex";
            // 
            // EnterCT
            // 
            this.EnterCT.BackColor = System.Drawing.Color.White;
            this.EnterCT.Font = new System.Drawing.Font("Microsoft Tai Le", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EnterCT.Location = new System.Drawing.Point(136, 27);
            this.EnterCT.Margin = new System.Windows.Forms.Padding(4);
            this.EnterCT.Multiline = true;
            this.EnterCT.Name = "EnterCT";
            this.EnterCT.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.EnterCT.Size = new System.Drawing.Size(306, 117);
            this.EnterCT.TabIndex = 18;
            // 
            // Decrypt
            // 
            this.Decrypt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(140)))), ((int)(((byte)(81)))));
            this.Decrypt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Decrypt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Decrypt.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(62)))), ((int)(((byte)(62)))));
            this.Decrypt.Location = new System.Drawing.Point(234, 152);
            this.Decrypt.Margin = new System.Windows.Forms.Padding(4);
            this.Decrypt.Name = "Decrypt";
            this.Decrypt.Size = new System.Drawing.Size(94, 31);
            this.Decrypt.TabIndex = 19;
            this.Decrypt.Text = "Decrypt";
            this.Decrypt.UseVisualStyleBackColor = false;
            this.Decrypt.Click += new System.EventHandler(this.Decrypt_Click);
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.Label17);
            this.groupBox9.Controls.Add(this.PrKey_d);
            this.groupBox9.Controls.Add(this.Copyd);
            this.groupBox9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox9.ForeColor = System.Drawing.SystemColors.InactiveCaption;
            this.groupBox9.Location = new System.Drawing.Point(8, 6);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(144, 191);
            this.groupBox9.TabIndex = 39;
            this.groupBox9.TabStop = false;
            this.groupBox9.Tag = "";
            this.groupBox9.Text = "Private key ";
            // 
            // Label17
            // 
            this.Label17.AutoSize = true;
            this.Label17.Location = new System.Drawing.Point(6, 41);
            this.Label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label17.Name = "Label17";
            this.Label17.Size = new System.Drawing.Size(33, 20);
            this.Label17.TabIndex = 22;
            this.Label17.Text = "d =";
            // 
            // PrKey_d
            // 
            this.PrKey_d.Location = new System.Drawing.Point(42, 41);
            this.PrKey_d.Margin = new System.Windows.Forms.Padding(4);
            this.PrKey_d.Name = "PrKey_d";
            this.PrKey_d.Size = new System.Drawing.Size(70, 27);
            this.PrKey_d.TabIndex = 14;
            // 
            // Copyd
            // 
            this.Copyd.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.Copyd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Copyd.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Copyd.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(62)))), ((int)(((byte)(62)))));
            this.Copyd.Location = new System.Drawing.Point(42, 111);
            this.Copyd.Margin = new System.Windows.Forms.Padding(4);
            this.Copyd.Name = "Copyd";
            this.Copyd.Size = new System.Drawing.Size(70, 33);
            this.Copyd.TabIndex = 13;
            this.Copyd.Text = "Copy";
            this.Copyd.UseVisualStyleBackColor = false;
            this.Copyd.Click += new System.EventHandler(this.Copyd_Click);
            // 
            // Dclear
            // 
            this.Dclear.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(62)))), ((int)(((byte)(62)))));
            this.Dclear.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Dclear.Font = new System.Drawing.Font("Segoe Print", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Dclear.ForeColor = System.Drawing.Color.MistyRose;
            this.Dclear.Location = new System.Drawing.Point(558, 388);
            this.Dclear.Margin = new System.Windows.Forms.Padding(4);
            this.Dclear.Name = "Dclear";
            this.Dclear.Size = new System.Drawing.Size(94, 41);
            this.Dclear.TabIndex = 38;
            this.Dclear.Text = "Clear";
            this.Dclear.UseVisualStyleBackColor = false;
            this.Dclear.Click += new System.EventHandler(this.Dclear_Click);
            // 
            // BackgroundWorker1
            // 
            this.BackgroundWorker1.DoWork += new System.ComponentModel.DoWorkEventHandler(this.BackgroundWorker1_DoWork);
            // 
            // BackgroundWorker2
            // 
            this.BackgroundWorker2.DoWork += new System.ComponentModel.DoWorkEventHandler(this.BackgroundWorker2_DoWork);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDark;
            this.ClientSize = new System.Drawing.Size(800, 516);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage3;
        internal System.Windows.Forms.Button btnClear;
        internal System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label5;
        internal System.Windows.Forms.TextBox txtCipherText_int;
        internal System.Windows.Forms.TextBox txtCipherText_hex;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox2;
        internal System.Windows.Forms.TextBox EnterPT;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button btnCopy;
        private System.Windows.Forms.TextBox txtPublicKey_n;
        private System.Windows.Forms.TextBox txtPublicKey_e;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox groupBox4;
        internal System.Windows.Forms.TextBox txtEnterPlain;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnEncrypt;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage1;
        internal System.Windows.Forms.Button Button1;
        internal System.Windows.Forms.Button Dexit;
        internal System.Windows.Forms.TextBox SENDTextBox;
        internal System.Windows.Forms.TextBox CHATTextBox;
        internal System.Windows.Forms.Button SENDButton;
        internal System.Windows.Forms.GroupBox groupBox1;
        internal System.Windows.Forms.Label label1;
        internal System.Windows.Forms.TextBox CTextBoxIP;
        internal System.Windows.Forms.Label Label9;
        internal System.Windows.Forms.TextBox CTextBoxPO;
        internal System.Windows.Forms.Button CONECTButton;
        internal System.Windows.Forms.GroupBox groupBox6;
        internal System.Windows.Forms.Label Label18;
        internal System.Windows.Forms.TextBox STextBoxIP;
        internal System.Windows.Forms.Label Label19;
        internal System.Windows.Forms.TextBox STextBoxPO;
        internal System.Windows.Forms.Button STARTButton;
        internal System.Windows.Forms.GroupBox groupBox7;
        internal System.Windows.Forms.Label Label15;
        internal System.Windows.Forms.Label Label16;
        internal System.Windows.Forms.TextBox ShowPT;
        internal System.Windows.Forms.TextBox PT_int;
        internal System.Windows.Forms.GroupBox groupBox8;
        internal System.Windows.Forms.Label Label14;
        internal System.Windows.Forms.TextBox EnterCT;
        internal System.Windows.Forms.Button Decrypt;
        internal System.Windows.Forms.GroupBox groupBox9;
        internal System.Windows.Forms.Label Label17;
        internal System.Windows.Forms.TextBox PrKey_d;
        internal System.Windows.Forms.Button Copyd;
        internal System.Windows.Forms.Button Dclear;
        internal System.ComponentModel.BackgroundWorker BackgroundWorker1;
        internal System.ComponentModel.BackgroundWorker BackgroundWorker2;
    }
}

