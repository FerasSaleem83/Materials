﻿namespace Calculator
{
    partial class frm_Keys
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_Keys));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtEnter_q = new System.Windows.Forms.TextBox();
            this.txtEnter_p = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtLabel_0N = new System.Windows.Forms.TextBox();
            this.txtLabel_N = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.txtEnter_e = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.btnCalculateKeys = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.txtLabel_d = new System.Windows.Forms.TextBox();
            this.txtLabel_e = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtEnter_q);
            this.groupBox1.Controls.Add(this.txtEnter_p);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.btnCalculate);
            this.groupBox1.Font = new System.Drawing.Font("Segoe Print", 10.2F);
            this.groupBox1.ForeColor = System.Drawing.Color.IndianRed;
            this.groupBox1.Location = new System.Drawing.Point(27, 25);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(373, 185);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Calculate N, 0N";
            // 
            // txtEnter_q
            // 
            this.txtEnter_q.Font = new System.Drawing.Font("Segoe Print", 10.2F);
            this.txtEnter_q.Location = new System.Drawing.Point(279, 78);
            this.txtEnter_q.Name = "txtEnter_q";
            this.txtEnter_q.Size = new System.Drawing.Size(59, 38);
            this.txtEnter_q.TabIndex = 14;
            // 
            // txtEnter_p
            // 
            this.txtEnter_p.Font = new System.Drawing.Font("Segoe Print", 10.2F);
            this.txtEnter_p.Location = new System.Drawing.Point(279, 34);
            this.txtEnter_p.Name = "txtEnter_p";
            this.txtEnter_p.Size = new System.Drawing.Size(59, 38);
            this.txtEnter_p.TabIndex = 13;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe Print", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(35, 86);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(227, 30);
            this.label2.TabIndex = 12;
            this.label2.Text = "Enter Prime Number (q)";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe Print", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(34, 42);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(228, 30);
            this.label1.TabIndex = 11;
            this.label1.Text = "Enter Prime Number (p)";
            // 
            // btnCalculate
            // 
            this.btnCalculate.BackColor = System.Drawing.Color.IndianRed;
            this.btnCalculate.Font = new System.Drawing.Font("Segoe Print", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalculate.ForeColor = System.Drawing.Color.Black;
            this.btnCalculate.Location = new System.Drawing.Point(116, 125);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(115, 51);
            this.btnCalculate.TabIndex = 10;
            this.btnCalculate.Text = "Calculate";
            this.btnCalculate.UseVisualStyleBackColor = false;
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtLabel_0N);
            this.groupBox2.Controls.Add(this.txtLabel_N);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Font = new System.Drawing.Font("Segoe Print", 10.2F);
            this.groupBox2.ForeColor = System.Drawing.Color.Gold;
            this.groupBox2.Location = new System.Drawing.Point(416, 25);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(373, 185);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Calculate N, 0N";
            // 
            // txtLabel_0N
            // 
            this.txtLabel_0N.Enabled = false;
            this.txtLabel_0N.Font = new System.Drawing.Font("Segoe Print", 10.2F);
            this.txtLabel_0N.Location = new System.Drawing.Point(105, 78);
            this.txtLabel_0N.Name = "txtLabel_0N";
            this.txtLabel_0N.Size = new System.Drawing.Size(59, 38);
            this.txtLabel_0N.TabIndex = 14;
            // 
            // txtLabel_N
            // 
            this.txtLabel_N.Enabled = false;
            this.txtLabel_N.Font = new System.Drawing.Font("Segoe Print", 10.2F);
            this.txtLabel_N.Location = new System.Drawing.Point(105, 34);
            this.txtLabel_N.Name = "txtLabel_N";
            this.txtLabel_N.Size = new System.Drawing.Size(59, 38);
            this.txtLabel_N.TabIndex = 13;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe Print", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(34, 86);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(64, 30);
            this.label3.TabIndex = 12;
            this.label3.Text = "0N = ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe Print", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(35, 42);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(52, 30);
            this.label4.TabIndex = 11;
            this.label4.Text = "N = ";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.txtEnter_e);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.btnCalculateKeys);
            this.groupBox3.Font = new System.Drawing.Font("Segoe Print", 10.2F);
            this.groupBox3.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.groupBox3.Location = new System.Drawing.Point(27, 216);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(373, 151);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Calculate N, 0N";
            // 
            // txtEnter_e
            // 
            this.txtEnter_e.Font = new System.Drawing.Font("Segoe Print", 10.2F);
            this.txtEnter_e.Location = new System.Drawing.Point(279, 29);
            this.txtEnter_e.Name = "txtEnter_e";
            this.txtEnter_e.Size = new System.Drawing.Size(59, 38);
            this.txtEnter_e.TabIndex = 13;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe Print", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(2, 37);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(271, 30);
            this.label6.TabIndex = 11;
            this.label6.Text = "Enter e (e < N, Prime to θN):";
            // 
            // btnCalculateKeys
            // 
            this.btnCalculateKeys.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btnCalculateKeys.Font = new System.Drawing.Font("Segoe Print", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalculateKeys.ForeColor = System.Drawing.Color.Black;
            this.btnCalculateKeys.Location = new System.Drawing.Point(116, 83);
            this.btnCalculateKeys.Name = "btnCalculateKeys";
            this.btnCalculateKeys.Size = new System.Drawing.Size(157, 51);
            this.btnCalculateKeys.TabIndex = 10;
            this.btnCalculateKeys.Text = "Calculate Keys";
            this.btnCalculateKeys.UseVisualStyleBackColor = false;
            this.btnCalculateKeys.Click += new System.EventHandler(this.btnCalculateKeys_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.txtLabel_d);
            this.groupBox4.Controls.Add(this.txtLabel_e);
            this.groupBox4.Controls.Add(this.label7);
            this.groupBox4.Controls.Add(this.label8);
            this.groupBox4.Font = new System.Drawing.Font("Segoe Print", 10.2F);
            this.groupBox4.ForeColor = System.Drawing.Color.MediumSpringGreen;
            this.groupBox4.Location = new System.Drawing.Point(416, 216);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(373, 151);
            this.groupBox4.TabIndex = 3;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Calculate N, 0N";
            // 
            // txtLabel_d
            // 
            this.txtLabel_d.Enabled = false;
            this.txtLabel_d.Font = new System.Drawing.Font("Segoe Print", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLabel_d.Location = new System.Drawing.Point(279, 72);
            this.txtLabel_d.Name = "txtLabel_d";
            this.txtLabel_d.Size = new System.Drawing.Size(59, 30);
            this.txtLabel_d.TabIndex = 14;
            // 
            // txtLabel_e
            // 
            this.txtLabel_e.Enabled = false;
            this.txtLabel_e.Font = new System.Drawing.Font("Segoe Print", 7.8F);
            this.txtLabel_e.Location = new System.Drawing.Point(279, 34);
            this.txtLabel_e.Name = "txtLabel_e";
            this.txtLabel_e.Size = new System.Drawing.Size(59, 30);
            this.txtLabel_e.TabIndex = 13;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe Print", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(35, 72);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(225, 30);
            this.label7.TabIndex = 12;
            this.label7.Text = "Your private key is (d) =";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe Print", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(35, 34);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(219, 30);
            this.label8.TabIndex = 11;
            this.label8.Text = "Your public  key is (e) =";
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.Black;
            this.btnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.ForeColor = System.Drawing.Color.White;
            this.btnExit.Location = new System.Drawing.Point(27, 390);
            this.btnExit.Margin = new System.Windows.Forms.Padding(4);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(94, 43);
            this.btnExit.TabIndex = 39;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnClear
            // 
            this.btnClear.BackColor = System.Drawing.Color.LightGray;
            this.btnClear.Font = new System.Drawing.Font("Segoe Print", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.Location = new System.Drawing.Point(695, 390);
            this.btnClear.Margin = new System.Windows.Forms.Padding(4);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(94, 43);
            this.btnClear.TabIndex = 38;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // frm_Keys
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoValidate = System.Windows.Forms.AutoValidate.EnablePreventFocusChange;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(801, 451);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frm_Keys";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Keys";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtEnter_q;
        private System.Windows.Forms.TextBox txtEnter_p;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtLabel_0N;
        private System.Windows.Forms.TextBox txtLabel_N;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox txtEnter_e;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnCalculateKeys;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox txtLabel_d;
        private System.Windows.Forms.TextBox txtLabel_e;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        internal System.Windows.Forms.Button btnExit;
        internal System.Windows.Forms.Button btnClear;
    }
}

