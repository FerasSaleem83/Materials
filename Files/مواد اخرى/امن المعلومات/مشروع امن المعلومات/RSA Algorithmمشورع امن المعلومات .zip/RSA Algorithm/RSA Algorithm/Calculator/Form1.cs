﻿using System;
using System.Reflection;
using System.Runtime.Remoting.Contexts;
using System.Security.Cryptography;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlTypes;

namespace Calculator
{
    public partial class frm_Keys : Form
    {
        private int q;
        private int p;
        private int n;
        private int z;
        private SqlInt64 ee = 0;
        public frm_Keys()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(txtEnter_p.Text, out p))
            {
                MessageBox.Show("Enter (p) as a Number", "Alert");
            }
            else if (!int.TryParse(txtEnter_q.Text, out q) || q < 1)
            {
                MessageBox.Show("Enter (q) as a Number", "Alert");
            }
            else if (p == q)
            {
                MessageBox.Show("p and q must be not equal!", "Alert");
            }
            else
            {
                bool isPPrime = IsPrime(p);
                bool isQPrime = IsPrime(q);

                if (isPPrime && isQPrime)
                {
                    n = p * q;
                    z = (p - 1) * (q - 1);
                    label4.Visible = true;
                    label3.Visible = true;
                    txtLabel_N.Visible = true;
                    txtLabel_0N.Visible = true;
                    txtEnter_e.Enabled = true;
                    txtLabel_N.Text = n.ToString();
                    txtLabel_0N.Text = z.ToString();

                    if (n < 127)
                    {
                        MessageBox.Show("(n) should be greater than 127, Please try again!", "Error");
                        n = 0;
                        z = 0;
                        txtEnter_p.Text = "";
                        txtEnter_q.Text = "";
                        label4.Visible = false;
                        label3.Visible = false;
                        txtLabel_N.Visible = false;
                        txtLabel_0N.Visible = false;
                    }
                    else
                    {
                        btnCalculateKeys.Enabled = true;
                    }
                }
                else
                {
                    if (!isPPrime)
                    {
                        MessageBox.Show($"{p} (p) is not a prime Number", "Error");
                    }
                    if (!isQPrime)
                    {
                        MessageBox.Show($"{q} (q) is not a prime Number", "Error");
                    }
                }
            }
        }
        // لتحديد اذا القيمة اولية او لا
        // القيمة الأولية هي القيمة التي تقبل القسمة على نفسها وواحد فقط
        private bool IsPrime(int number)
        {
            if (number <= 1)
            {
                return false;
            }

            for (int i = 2; i < number; i++)
            {
                if (number % i == 0)
                {
                    return false;
                }
            }

            return true;
        }

        private void btnCalculateKeys_Click(object sender, EventArgs e)
        {
            ee = SqlInt64.Parse(txtEnter_e.Text);

            if (!int.TryParse(txtEnter_e.Text, out int eValue))
            {
                MessageBox.Show("Enter (e) as a Number", "Alert");
            }
            else if (ee > n)
            {
                MessageBox.Show("(e) should be smaller than (n)", "Alert");
            }
            else
            {
                bool isEPrime = IsPrime(eValue);

                if (isEPrime)
                {
                    SqlInt64 dd = 0;
                    SqlInt64 ddd = 0;
                    int min = 0;
                    int max = 0;

                    do
                    {
                        Random random = new Random();
                        max++;
                        dd = random.Next(Math.Min(min, max), Math.Max(min, max));
                        ddd = ee * dd % z;
                    } while (ddd != 1);

                    txtLabel_N.Text = n.ToString();
                    txtLabel_e.Text = ee.Value.ToString("N0");
                    txtLabel_d.Text = dd.Value.ToString("N0");
                }
                else
                {
                    MessageBox.Show("(e) is not a prime Number", "Error");
                }
            }
        }

        // لإزالة القيم الموجودة في مربعات النصوص
        private void btnClear_Click(object sender, EventArgs e)
        {
            btnCalculateKeys.Enabled = false;
            label4.Visible = false;
            label3.Visible = false;
            txtEnter_e.Enabled = false;
            txtEnter_p.Text = "";
            txtEnter_q.Text = "";
            txtEnter_e.Text = "";
            txtLabel_N.Text = "";
            txtLabel_0N.Text = "";
            txtLabel_e.Text = "";
            txtLabel_d.Text = "";

            p = 0;
            q = 0;
            n = 0;
            z = 0;
            ee = 0;
        }

        //لإغلاق البرنامج
        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
